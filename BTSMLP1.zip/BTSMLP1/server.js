const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static("public")); 

app.get("/bautismos.html", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "bautismos.html"));
});

app.get("/usuarios", (req, res) => {
  const filePath = path.join(__dirname, "data", "eventos.json");
  const data = JSON.parse(fs.readFileSync(filePath, "utf-8"));
  res.json(data.usuarios); 
});

app.post("/register", (req, res) => {
  const { username, password } = req.body;
  const filePath = path.join(__dirname, "data", "eventos.json");
  const data = JSON.parse(fs.readFileSync(filePath, "utf-8"));

  if (data.usuarios.some(user => user.username === username)) {
    return res.status(400).json({ error: "El usuario ya está registrado." });
  }

  data.usuarios.push({ username, password });
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

  res.status(201).json({ message: "Usuario registrado con éxito." });
});

app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const filePath = path.join(__dirname, "data", "eventos.json");
  const data = JSON.parse(fs.readFileSync(filePath, "utf-8"));

  const user = data.usuarios.find(
    (user) => user.username === username && user.password === password
  );

  if (!user) {
    return res.status(401).json({ error: "Credenciales inválidas." });
  }

  res.status(200).json({ message: "Inicio de sesión exitoso.", redirect: "/bautismos.html" });
});

app.delete("/usuarios/:id", (req, res) => {
  const { id } = req.params;
  const filePath = path.join(__dirname, "data", "eventos.json");
  const data = JSON.parse(fs.readFileSync(filePath, "utf-8"));

  if (id >= data.usuarios.length || id < 0) {
    return res.status(404).json({ error: "Usuario no encontrado." });
  }

  data.usuarios.splice(id, 1);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

  res.status(200).json({ message: "Usuario eliminado con éxito." });
});

app.put("/usuarios/:id", (req, res) => {
  const { id } = req.params;
  const { username, password } = req.body;
  const filePath = path.join(__dirname, "data", "eventos.json");
  const data = JSON.parse(fs.readFileSync(filePath, "utf-8"));

  if (id >= data.usuarios.length || id < 0) {
    return res.status(404).json({ error: "Usuario no encontrado." });
  }

  data.usuarios[id] = { username, password };
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

  res.status(200).json({ message: "Usuario actualizado con éxito." });
});

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "principal.html"));
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
